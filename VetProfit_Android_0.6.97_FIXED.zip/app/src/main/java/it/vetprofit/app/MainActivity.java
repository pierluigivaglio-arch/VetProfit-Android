package it.vetprofit.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private WebView web;
  private ValueCallback<Uri[]> fileCallback;
  private static final int PICK_FILE=10, CREATE_BACKUP=11;
  private String pendingBackup="";

  @Override public void onCreate(Bundle b){super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(242,242,247));
    getWindow().setNavigationBarColor(Color.WHITE);
    if(Build.VERSION.SDK_INT>=23)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    web=new WebView(this); web.setBackgroundColor(Color.rgb(242,242,247)); setContentView(web);
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    s.setLoadWithOverviewMode(false); s.setUseWideViewPort(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
    web.addJavascriptInterface(new AndroidBridge(),"Android");
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
        if(fileCallback!=null)fileCallback.onReceiveValue(null); fileCallback=cb;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json");
        try{startActivityForResult(i,PICK_FILE);}catch(Exception e){fileCallback=null;return false;} return true;
      }
    });
    web.loadUrl("file:///android_asset/index.html");
  }

  public class AndroidBridge {
    @JavascriptInterface public void saveBackup(String json,String filename){
      pendingBackup=json==null?"":json;
      runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,filename==null?"VetProfit_backup.json":filename);startActivityForResult(i,CREATE_BACKUP);});
    }
  }

  @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);
    if(req==PICK_FILE&&fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res,data));fileCallback=null;return;}
    if(req==CREATE_BACKUP&&res==RESULT_OK&&data!=null&&data.getData()!=null){
      try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));out.flush();}
      catch(Exception e){new AlertDialog.Builder(this).setMessage("Impossibile salvare il backup: "+e.getMessage()).setPositiveButton("OK",null).show();}
      pendingBackup="";
    }
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
